package com.cog.pojo;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="room1")
public class Room 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="roomno")
	private int RoomNo;
	@Column(name="roomName")
	private String RoomName;
	@OneToOne(mappedBy="room",cascade=CascadeType.ALL)
	private Event event;
	
	private List<Participants> part;

	public List<Participants> getPart() {
		return part;
	}

	public void setPart(List<Participants> part) {
		this.part = part;
	}

	public int getRoomNo() {
		return RoomNo;
	}

	public void setRoomNo(int roomNo) {
		RoomNo = roomNo;
	}

	public String getRoomName() {
		return RoomName;
	}

	public void setRoomName(String roomName) {
		RoomName = roomName;
	}

	public Event getEvent() {
		return event;
	}

	public void setEvent(Event event) {
		this.event = event;
	}
	
	
	
	
	

}
