package com.cognizant.day2.resources;

import javax.jms.Session;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil 
{
 
	public static SessionFactory Getfactory()
	{
		return new Configuration().configure("com/cognizant/day2/resources/hibernate.cfg.xml").buildSessionFactory();
		
	} 

}
