package com.cognizant.day2.utility;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.cognizant.day2.dao.Team_Player;
import com.cognizant.day2.entity.Player;
import com.cognizant.day2.entity.Team;

public class Test_Team_Player 
{
	public static void main(String[] args) {
		Team_Player tp=new Team_Player();
		
		/*Team t=new Team();
		t.setTeam_name("WestIndies");
		List<Player> p=new ArrayList<Player>();
		
		Player pr=new Player();
		pr.setPlayer_name("gyle");
		pr.setTeam(t);
		p.add(pr);
		
		pr=new Player();
		pr.setPlayer_name("polard");
		pr.setTeam(t);
		p.add(pr);
		
		tp.Add_Team_Player(t, p);*/
		
		for(Team t:tp.GetAll_Team_Players())
		{
			System.out.println(t.getTeam_name());
			for(Player p:t.getPlayerList())
			{
				System.out.println(p.getPlayer_name());
			}
		}
		
		
	}

}
