package com.cognizant.day2.utility;

import java.util.ArrayList;
import java.util.List;

import com.cognizant.day2.dao.Train_Course;
import com.cognizant.day2.entity.Courses;
import com.cognizant.day2.entity.Training;

public class Training_Course_Test 
{
	public static void main(String[] args) {
		
		Train_Course tc=new Train_Course();
		
		List<Training> tl=new ArrayList<Training>();
		List<Courses> cl=new ArrayList<Courses>();
		
		Training t=new Training();
		t.setTrain_Name("simha");
		tl.add(t);
		t=new Training();
		t.setTrain_Name("jaya");
		tl.add(t);
		
		
		Courses c=new Courses();
		c.setCourse_Name("hibernate");
		c.setTrainingList(tl);
		cl.add(c);
		
		
		tc.Get_Train_Course(tl, cl);
		
	}

}
