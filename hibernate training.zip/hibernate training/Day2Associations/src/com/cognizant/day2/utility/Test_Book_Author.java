package com.cognizant.day2.utility;

import java.util.Date;

import com.cognizant.day2.dao.Book_Author;
import com.cognizant.day2.entity.Author;
import com.cognizant.day2.entity.Book;

public class Test_Book_Author 
{
	public static void main(String[] args) {
		Book_Author ba=new Book_Author();
		Book b=new Book();
		b.setBook_Name("java");
		b.setBook_Date_of_Publish(new Date(97,2,2));
		Author a=new Author();
		a.setAuthor_Name("simha");
		ba.Add_Book_Author(b, a);
		
	}

}
