package com.cognizant.day2.utility;

import java.util.Date;
import java.util.Iterator;

import com.cognizant.day2.dao.Manager;
import com.cognizant.day2.entity.Address;
import com.cognizant.day2.entity.Customer;

public class TestManager 
{
	public static void main(String[] args) {
		/*Manager m=new Manager();
		Address  a=new Address();
		a.setStreet("thoraiopakkam");
		a.setCity("chennai");
		a.setState("tamilnadu");
		Customer c=new Customer();
		c.setCustomer_Name("simha");
		c.setDate_of_Birth(new Date(92,07,15));
		m.AddCustomer_Address(c, a);*/
		Manager m=new Manager();
		Iterator itr=m.GetAll().iterate();
		System.out.println("Customer_Id"+"\t"+"Customer_name"+"\t"+"date_of_Birth"+"\t"+"street"+"\t"+"city"+"\t"+"State");
		
		while (itr.hasNext())
		{
			//System.out.println(itr.next());
			Object[] obj=(Object[])itr.next();
			System.out.println(obj[0]+"\t"+obj[1]+"\t"+obj[2]+"\t"+obj[3]+"\t"+obj[4]+"\t"+obj[5]);
		}
	}

}
