package com.cognizant.day2.test;

import static org.junit.Assert.*;

import java.util.Iterator;

import org.junit.After;
import org.junit.Test;

import com.cognizant.day2.dao.Manager;

public class Testing1 {

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		Manager m=new Manager();
		Iterator itr=m.GetAll().iterate();
		System.out.println("Customer_Id"+"\t"+"Customer_name"+"\t"+"date_of_Birth"+"\t"+"street"+"\t"+"city"+"\t"+"State");
		
		while (itr.hasNext())
		{
			//System.out.println(itr.next());
			Object[] obj=(Object[])itr.next();
			System.out.println(obj[0]+"\t"+obj[1]+"\t"+obj[2]+"\t"+obj[3]+"\t"+obj[4]+"\t"+obj[5]);
		}
	}

}
