package com.cognizant.day2.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cognizant.day2.entity.Address;
import com.cognizant.day2.entity.Customer;
import com.cognizant.day2.resources.HibernateUtil;

public class Manager 
{
	private SessionFactory sf;
	private Session s;
	private boolean status;
	
	public Manager()
	{
		sf=HibernateUtil.Getfactory();
	}
	public boolean AddCustomer_Address(Customer c,Address a)
	{
		s=sf.openSession();
		s.beginTransaction();
		
		try {
			//s.save(a);
			s.persist(a);
			c.setAddress(a);
			s.persist(c);
			s.getTransaction().commit();
			status=true;
		} 
		catch (HibernateException e) {
			s.getTransaction().rollback();
		}
		return status;
		
	}
	public Query GetAll()
	{
	    s=sf.openSession();
	    return s.createQuery("select c.customer_Id,c.customer_Name,c.date_of_Birth,a.street,a.city,a.State from Customer c inner join c.address a");
		
	}
	//retrives all the records
	

}
