package com.cognizant.day2.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cognizant.day2.entity.Courses;
import com.cognizant.day2.entity.Training;
import com.cognizant.day2.resources.HibernateUtil;

public class Train_Course 
{
	private SessionFactory sf;
	private Session s;
	
	private boolean status;
	
	public Train_Course()
	{
		sf=HibernateUtil.Getfactory();
	}
	
	
	public boolean Get_Train_Course(List<Training> tl,List<Courses> c)
	{
		s=sf.openSession();
		s.beginTransaction();
		
		try
		{
		for(Training t:tl)
		{
			t.setCourseList(c);
			s.save(t);
			s.getTransaction().commit();
		}
		}
		catch(HibernateException e)
		{
			s.getTransaction().rollback();
			
		}
		
		return status;
		
	}
	
	

}
