package com.cognizant.day2.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cognizant.day2.entity.Player;
import com.cognizant.day2.entity.Team;
import com.cognizant.day2.resources.HibernateUtil;

public class Team_Player 
{
	private SessionFactory sf;
	private Session s;
	private boolean status;
	
	public Team_Player()
	{
		sf=HibernateUtil.Getfactory();
	}
	public boolean Add_Team_Player(Team t,List<Player> p)
	{
		s=sf.openSession();
		s.beginTransaction();
		try
		{
			
		t.setPlayerList(p);
			
			s.save(t);
			s.getTransaction().commit();
			status=true;
		}
		catch(HibernateException e)
		{
			s.getTransaction().rollback();
		}
		s.close();
		return status;
	}
		
		public List<Team> GetAll_Team_Players()
		{
		    s=sf.openSession();
		    return s.createQuery("from Team").list();
			
	}

}
