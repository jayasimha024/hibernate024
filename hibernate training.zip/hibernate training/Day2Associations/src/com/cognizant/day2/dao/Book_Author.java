package com.cognizant.day2.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cognizant.day2.entity.Author;
import com.cognizant.day2.entity.Book;
import com.cognizant.day2.resources.HibernateUtil;

public class Book_Author 
{
	private SessionFactory sf;
	private Session s;
	private boolean status;
	
	public Book_Author()
	{
		sf=HibernateUtil.Getfactory();		
	}
	
	public boolean Add_Book_Author(Book b,Author a)
	{
		s=sf.openSession();
		s.beginTransaction();
		
		try
		{
			//it is bidirectional so we are saving only one time
			a.setBook(b);
			b.setAuthor(a);
			s.persist(b);
			s.getTransaction().commit();
			status=true;
		}
		catch(HibernateException e)
		{
			s.getTransaction().rollback();
		}
		s.close();
		return status;
		
	}
	

}
