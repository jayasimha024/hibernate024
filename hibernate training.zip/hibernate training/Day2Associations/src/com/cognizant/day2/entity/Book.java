package com.cognizant.day2.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Cascade;

@Entity
@Table(name="book")
public class Book 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="book_isbn")
	private int Book_Isbn;
	@Column(name="book_name")
	private String Book_Name;
	@Temporal(TemporalType.DATE)
	@Column(name="dateOfPublish")
	private Date Book_Date_of_Publish;
	
	@OneToOne(mappedBy="book",cascade=CascadeType.ALL)
	private Author author;
	
	
	public int getBook_Isbn() {
		return Book_Isbn;
	}
	public void setBook_Isbn(int book_Isbn) {
		Book_Isbn = book_Isbn;
	}
	public String getBook_Name() {
		return Book_Name;
	}
	public void setBook_Name(String book_Name) {
		Book_Name = book_Name;
	}
	public Date getBook_Date_of_Publish() {
		return Book_Date_of_Publish;
	}
	public void setBook_Date_of_Publish(Date book_Date_of_Publish) {
		Book_Date_of_Publish = book_Date_of_Publish;
	}
	public Author getAuthor() {
		return author;
	}
	public void setAuthor(Author author) {
		this.author = author;
	}
	
	
	
	
	

}
