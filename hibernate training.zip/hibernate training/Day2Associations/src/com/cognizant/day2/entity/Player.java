package com.cognizant.day2.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="player")
public class Player 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="playerId")
	private int player_Id;
	@Column(name="playerName")
	private String Player_name;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="Team_id",nullable=false)
	private Team team;
	
	
	public int getPlayer_Id() {
		return player_Id;
	}
	public void setPlayer_Id(int player_Id) {
		this.player_Id = player_Id;
	}
	public String getPlayer_name() {
		return Player_name;
	}
	public void setPlayer_name(String player_name) {
		Player_name = player_name;
	}
	public Team getTeam() {
		return team;
	}
	public void setTeam(Team team) {
		this.team = team;
	}
	
	

}
