package com.cognizant.day2.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="training")
public class Training 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="t_id")
	private int Train_Id;
	@Column(name="t_name")
	private String Train_Name;
	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="Train_Course",joinColumns={@JoinColumn(name="Train_Id")},inverseJoinColumns={@JoinColumn(name="Corses_Id")})
	private List<Courses> courseList;


	public int getTrain_Id() {
		return Train_Id;
	}


	public void setTrain_Id(int train_Id) {
		Train_Id = train_Id;
	}


	public String getTrain_Name() {
		return Train_Name;
	}


	public void setTrain_Name(String train_Name) {
		Train_Name = train_Name;
	}


	public List<Courses> getCourseList() {
		return courseList;
	}


	public void setCourseList(List<Courses> courseList) {
		this.courseList = courseList;
	}
	
	

}
