package com.cognizant.day2.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;

@Entity
@Table(name="Team")
public class Team 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="TeamId")
	private int Team_Id;
	@Column(name="TeamName")
	private String Team_name;
	
	@OneToMany(mappedBy="team",fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	private List<Player> playerList;
	
	public int getTeam_Id() {
		return Team_Id;
	}
	public void setTeam_Id(int team_Id) {
		Team_Id = team_Id;
	}
	public String getTeam_name() {
		return Team_name;
	}
	public void setTeam_name(String team_name) {
		Team_name = team_name;
	}
	public List<Player> getPlayerList() {
		return playerList;
	}
	public void setPlayerList(List<Player> playerList) {
		this.playerList = playerList;
	}
		
	

}
