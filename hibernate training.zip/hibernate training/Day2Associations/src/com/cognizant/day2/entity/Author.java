package com.cognizant.day2.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name="author")
public class Author {
	@Id
	@Column(name="author_id")
	@GeneratedValue(generator="gen")
	@GenericGenerator(name="gen",strategy="foreign",parameters=@Parameter(name="property",value="book"))
	private int Author_Id;
	@Column(name="author_name")
	private String Author_Name;
	
	@OneToOne
	@PrimaryKeyJoinColumn
	private Book book;	
	
	public int getAuthor_Id() {
		return Author_Id;
	}
	public void setAuthor_Id(int author_Id) {
		Author_Id = author_Id;
	}
	public String getAuthor_Name() {
		return Author_Name;
	}
	public void setAuthor_Name(String author_Name) {
		Author_Name = author_Name;
	}
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	
	
	
	

}
