package com.cognizant.day2.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="course")
public class Courses 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="c_id")
	private int course_Id;
	@Column(name="c_name")
	private String Course_Name;
	
	@ManyToMany(mappedBy="courseList")
	
	private List<Training> TrainingList;
	
	public int getCourse_Id() {
		return course_Id;
	}

	public void setCourse_Id(int course_Id) {
		this.course_Id = course_Id;
	}

	public String getCourse_Name() {
		return Course_Name;
	}

	public void setCourse_Name(String course_Name) {
		Course_Name = course_Name;
	}

	public List<Training> getTrainingList() {
		return TrainingList;
	}

	public void setTrainingList(List<Training> trainingList) {
		TrainingList = trainingList;
	}

	

}
