package com.cognizant.simha.resources;

import javax.jms.Session;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil 
{
 
	public static SessionFactory Getfactory()
	{
		return new Configuration().configure("com/cognizant/simha/resources/hibernate.cfg.xml").buildSessionFactory();
		
	} 

}
