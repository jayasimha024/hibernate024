package com.cognizant.simha.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Test;

import com.cognizant.simha.dao.EventManager;
import com.cognizant.simha.entities.Event;
import com.cognizant.simha.entities.EventKey;

public class EventTest {

	@After
	public void tearDown() throws Exception 
	{
		
	}

	@Test
	public void test() {
		EventManager em=new EventManager();
		EventKey ek=new EventKey();
		ek.setEventId(2);
		ek.setTrainerId(200);
		Event event=new Event();
		event.setDuration(5);
		event.setLocation("chennai");
		event.setEventName("Hibernate Training");
		event.setEventid(ek);//event id is for creating the table
		assertTrue(em.AddEvent(event));
	}

}
