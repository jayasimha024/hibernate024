package com.cognizant.simha.utility;

import java.util.Scanner;

import com.cognizant.simha.dao.EventManager;
import com.cognizant.simha.dao.RoomManager;
import com.cognizant.simha.entities.Event;
import com.cognizant.simha.entities.EventKey;
import com.cognizant.simha.entities.TrainingRoom;

public class TestApp 
{
	public static void main(String[] args) 
	{
		/*RoomManager rm=new RoomManager();
		TrainingRoom tr=new TrainingRoom();
		tr.setLocation("mepz");
		tr.setCapacity(30);
		tr.setSystem_Avl(true);
		tr.setProjector_Avl(true);
		if(rm.AddRoom(tr))
			{
			System.out.println("record added");
			}
		for(TrainingRoom tr:rm.GetAllRooms())
		{
			System.out.println(tr.getRoomNo());
			System.out.println(tr.getCapacity());
		}
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Room No1");
		int roomNo1=sc.nextInt();
		System.out.println("Enter Room No2");
		int roomNo2=sc.nextInt();
		rm.roomEvict_clear(roomNo1, roomNo2);
		rm.UpdateRoom(roomNo);
		rm.DeleteRoom(roomNo);
		rm.SessionClose(roomNo1);*/
		
		//composite id
		EventManager em=new EventManager();
		EventKey ek=new EventKey();
		ek.setEventId(2);
		ek.setTrainerId(200);
		Event event=new Event();
		event.setDuration(5);
		event.setLocation("chennai");
		event.setEventName("Hibernate Training");
		event.setEventid(ek);//event id is for creating the table
		em.AddEvent(event);
		
	}
	
}
