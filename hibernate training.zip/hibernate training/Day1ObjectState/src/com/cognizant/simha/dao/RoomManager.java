package com.cognizant.simha.dao;


import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cognizant.simha.entities.TrainingRoom;
import com.cognizant.simha.resources.HibernateUtil;

public class RoomManager 
{
	private SessionFactory factory;
	private Session session;
	
	public RoomManager() {
		factory=HibernateUtil.Getfactory();
		
	}
	public boolean AddRoom(TrainingRoom room)
	{
		boolean status=false;
		
		session=factory.openSession();
		session.beginTransaction();
		
		try{
			session.save(room);	
			session.getTransaction().commit();
			status=true;
		}
		catch(HibernateException ex)
		{
			session.getTransaction().rollback();
		}
		session.close();
		return status;
		
	}
	public List<TrainingRoom> GetAllRooms()
	{
		session=factory.openSession();
		Query query=session.createQuery("from TrainingRoom");
		return query.list();
		
	}
	public boolean UpdateRoom(int roomNo)
	{
		boolean status=false;
		session=factory.openSession();
		TrainingRoom tr=(TrainingRoom) session.get(TrainingRoom.class, roomNo);
		tr.setCapacity(550);
		tr.setSystem_Avl(false);
		session.beginTransaction();
		try
		{
			//session.update(tr);
			session.getTransaction().commit();
			status=true;
		}
		catch(HibernateException ex)
		{
			session.getTransaction().rollback();
		}
		return status;
		
	}
	public boolean DeleteRoom(int roomNo)
	{
		boolean status=false;
		session=factory.openSession();
		TrainingRoom tr=(TrainingRoom) session.get(TrainingRoom.class, roomNo);
		
		session.beginTransaction();
		try
		{
			session.delete(tr);
			session.getTransaction().commit();
			status=true;
		}
		catch(HibernateException ex)
		{
			session.getTransaction().rollback();
		}
		return status;
		
	}
	public boolean roomEvict_clear(int roomNo1,int roomNo2)
	{
		boolean status=false;
		
		session=factory.openSession();
		TrainingRoom obj1=(TrainingRoom) session.get(TrainingRoom.class, roomNo1);
		TrainingRoom obj2=(TrainingRoom) session.get(TrainingRoom.class, roomNo2);
		//modify object1 and object2
		//session.evict(obj2);// obj2 detached from the session
		session.clear();
		session.beginTransaction();
		obj1.setCapacity(12);
		obj2.setCapacity(100);
		session.getTransaction().commit();
		status=true;
		session.close();
		
		return status;
	}
	public boolean SessionClose(int roomNo)
	{
		boolean status=false;
		
		session=factory.openSession();
		TrainingRoom tr=(TrainingRoom) session.get(TrainingRoom.class,roomNo);
		session.close();
		
		tr.setCapacity(67);
		
		Session session1=factory.openSession();
		session1.beginTransaction();
		TrainingRoom tr1=(TrainingRoom) session1.get(TrainingRoom.class,roomNo);
		session1.merge(tr);
		session1.getTransaction().commit();
		status=true;
		return status;
		
	}

}
